﻿using System;
using ClassLibrary4;
using ViewModel;

namespace Test2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("=== בדיקת שליפת ביקורות ===");
                ReviewsDB reviewsDB = new ReviewsDB();
                ReviewList reviewList = reviewsDB.SelectAll();

                foreach (Review review in reviewList)
                {
                    Console.WriteLine($"ביקורת ID: {review.Id} | דירוג: {review.Rating}/5");
                    Console.WriteLine($"תוכן: {review.CommentText}");

                    if (review.Cook != null)
                    {
                        Console.WriteLine($"   טבח/כותב: {review.Cook.Bio}");
                    }
                    if (review.Recipe != null)
                    {
                        Console.WriteLine($"   עבור המתכון: {review.Recipe.Title}");
                    }
                    Console.WriteLine(new string('-', 30));
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"שגיאה: {ex.Message}");
            }

            Console.WriteLine("\nלחץ על מקש כלשהו לסיום...");
            Console.ReadKey();
        }
    }
}