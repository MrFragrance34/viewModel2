﻿using ClassLibrary4;
using System;
using System.Net;

namespace ViewModel
{
    public class RecipesDB : BaseDB
    {
        public RecipeList SelectAll()
        {
            command.CommandText = "SELECT * FROM Recipes";
            RecipeList list = new RecipeList(base.Select());
            return list;
        }

        public Recipe SelectById(int id)
        {
            command.CommandText = $"SELECT * FROM Recipes WHERE ID = {id}";
            RecipeList list = new RecipeList(base.Select());
            if (list.Count > 0)
                return list[0];
            return null;
        }

        public override BaseEntity NewEntity()
        {
            return new Recipe();
        }

        protected override BaseEntity CreateModel(BaseEntity entity)
        {
            Recipe recipe = entity as Recipe;
            recipe.Title = reader["Title"].ToString();
            recipe.Description = reader["Description"].ToString();
            recipe.Instructions = reader["Instructions"].ToString();

            if (reader["PrepTimeMins"] != DBNull.Value)
                recipe.PrepTimeMins = Convert.ToInt32(reader["PrepTimeMins"]);

            if (reader["CookID"] != DBNull.Value)
            {
                int cookId = Convert.ToInt32(reader["CookID"]);
                CookDB cookDB = new CookDB();
                recipe.Cook = cookDB.SelectById(cookId);
            }

            base.CreateModel(entity);
            return entity;
        }
    }
}