﻿using ClassLibrary4;
using System;
using System.Net;

namespace ViewModel
{
    public class ReviewsDB : BaseDB
    {
        public ReviewList SelectAll()
        {
            command.CommandText = "SELECT * FROM Reviews";
            ReviewList list = new ReviewList(base.Select());
            return list;
        }

        public Review SelectById(int id)
        {
            command.CommandText = $"SELECT * FROM Reviews WHERE ID = {id}";
            ReviewList list = new ReviewList(base.Select());
            if (list.Count > 0)
                return list[0];
            return null;
        }

        public override BaseEntity NewEntity()
        {
            return new Review();
        }

        protected override BaseEntity CreateModel(BaseEntity entity)
        {
            Review review = entity as Review;
            review.Rating = Convert.ToInt32(reader["Rating"]);
            review.CommentText = reader["CommentText"].ToString();

            if (reader["CookID"] != DBNull.Value)
            {
                int cookId = Convert.ToInt32(reader["CookID"]);
                CookDB cookDB = new CookDB();
                review.Cook = cookDB.SelectById(cookId);
            }

            if (reader["RecipeID"] != DBNull.Value)
            {
                int recipeId = Convert.ToInt32(reader["RecipeID"]);
                RecipesDB recipesDB = new RecipesDB();
                review.Recipe = recipesDB.SelectById(recipeId);
            }

            base.CreateModel(entity);
            return entity;
        }
    }
}