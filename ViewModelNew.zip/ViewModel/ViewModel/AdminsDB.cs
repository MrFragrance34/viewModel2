﻿using System;
using ClassLibrary4;

namespace ViewModel
{
    public class AdminsDB : BaseDB
    {
        public AdminList SelectAll() 
        {
            command.CommandText = "SELECT * FROM Admins";
            AdminList list = new AdminList(base.Select());
            return list;
        }

        public override BaseEntity NewEntity()
        {
            return new Admin();
        }

        protected override BaseEntity CreateModel(BaseEntity entity)
        {
            Admin admin = entity as Admin;
            admin.AdminRole = reader["AdminRole"].ToString();

            base.CreateModel(entity);
            return entity;
        }
    }
}